#!/bin/sh

echo There are $# files to be proccesed

for inFile in $*
do
  outFile=$(echo $inFile |  sed 's/md/op/g')
  ./op_calc 1 2.35 $inFile $outFile
done